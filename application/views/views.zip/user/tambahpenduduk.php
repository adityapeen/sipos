<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-4 text-gray-800">Tambah Penduduk</h1>
    <div class="row d-flex justify-content-center">
        <div class=" col-md-8">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">Data Penduduk</h4>
                </div>
                <div class="card-body">
                    <form method="post" action="<?= base_url('user/tambahpenduduk') ?>">
                        <b>* Wajib di isi</b>
                        <div class="row">
                            <div class="col-md-5">
                                <div class="form-group">
                                    <label>NIK*</label>
                                    <?= form_error('nik', '<small class="text-danger pl-3">', '</small>'); ?>
                                    <input type="text" class="form-control" name="nik" id="nik" placeholder="Nomor Induk Kependudukan" required>
                                </div>
                            </div>
                            <div class="col-md-7">
                                <div class="form-group">
                                    <label>Nama Lengkap*</label>
                                    <?= form_error('nama', '<small class="text-danger pl-3">', '</small>'); ?>
                                    <input type="text" class="form-control" name="nama" id="nama" placeholder="Nama Lengkap Penduduk" required>
                                </div>
                            </div>

                        </div>
                        <div class="row">
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="jk">Jenis Kelamin*</label>
                                    <select id="jk" name="jk" class="form-control">
                                        <option selected value="L">Laki-laki</option>
                                        <option value="P">Perempuan</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label>Tempat Lahir</label>
                                    <?= form_error('tgllahir', '<small class="text-danger pl-3">', '</small>'); ?>
                                    <input type="text" id="tempatlahir" name="tempatlahir" class="form-control" placeholder="Tempat Lahir" value="">
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label>Tanggal Lahir*</label>
                                    <input type="date" class="form-control" id="tanggallahir" name="tanggallahir" placeholder="Tanggal Lahir" value="">
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-2">
                                <div class="form-group">
                                    <label>Agama*</label>
                                    <select id="agama" class="form-control">
                                        <option value=1 selected>Islam</option>
                                        <option value=2>Kristen</option>
                                        <option value=3>Katolik</option>
                                        <option value=4>Hindu</option>
                                        <option value=5>Buddha</option>
                                        <option value=6>Kong Hu Cu</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-5">
                                <div class="form-group">
                                    <label>Pekerjaan</label>
                                    <input type="text" class="form-control" id="pekerjaan" name="pekerjaan" placeholder="Pekerjaan" value="">
                                </div>
                            </div>
                            <div class="col-md-5">
                                <div class="form-group">
                                    <label>Alamat</label>
                                    <?= form_error('idposyandu', '<small class="text-danger pl-3">', '</small>'); ?>
                                    <input type="text" class="form-control" id="alamat" name="alamat" placeholder="Alamat" value="">
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label>Ibu</label>
                                    <input type="text" class="form-control" id="ibu" name="ibu" placeholder="Nama Ibu" value="" readonly>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label>Ayah</label>
                                    <input type="text" class="form-control" id="ayah" name="ayah" placeholder="Nama Ayah" value="" readonly>
                                </div>
                            </div>
                            <div class="col-md-2">
                                <div class="form-group">
                                    <label>Kartu KMS</label>
                                    <select id="kms" name="kms" class="form-control">
                                        <option value=1 selected>Ya</option>
                                        <option value=0>Tidak</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-2">
                                <div class="form-group">
                                    <label>Status Bantuan</label>
                                    <input type="text" class="form-control" id="statusbantuan" name="statusbantuan" placeholder="Bantuan saat ini" value="">
                                </div>
                            </div>
                        </div>
                        <input type="hidden" name="idposyandu" value="<?= $user['idposyandu']; ?>">

                        <button type="submit" class="btn btn-info btn-fill pull-right">Simpan</button>
                        <button onclick="goBack()" href="#" type="button" class="btn btn-warning btn-fill pull-right">Batal</button>
                        <div class="clearfix"></div>
                    </form>
                </div>
            </div>
        </div>
    </div>

</div>
<!-- /.container-fluid -->

<script type="text/javascript">
    $(document).ready(function() {
        $("#ayah").autocomplete({
            source: ["c++", "java", "php", "coldfusion", "javascript", "asp", "ruby"]
        });
        $("#ayah").keyup(function() {
            alert("Handler for .keyup() called.");
        });
    });
</script>
<script src="<?php echo base_url(); ?>assets/js/ajax.js"></script>

<!-- <script>
    function autofill() {
        var nama = document.getElementById('ayah').value;
        $.ajax({
            url: "<?php echo base_url('api/cari'); ?>",
            data: '&nama=' + nama,
            success: function(data) {
                var hasil = JSON.parse(data);

                $.each(hasil, function(key, val) {

                    document.getElementById('ayah').value = val.nama;

                });
            }
        });

    }
</script> -->
</div>
<!-- End of Main Content -->