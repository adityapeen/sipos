<!-- Begin Page Content -->
<div class="container-fluid">
    <p class="text-center">FORMULIR PENILAIAN STATUS GIZI BAYI DAN BALITA <?= strtoupper($posyandu['namaposyandu']) . " (DUSUN " . strtoupper($posyandu['dusun'] . ")"); ?>
        <br> <b>Bulan <?= date('F', strtotime($beritaacara[0]->tglacara)); ?>
            &nbsp; &nbsp;Tahun <?= date('Y', strtotime($beritaacara[0]->tglacara)); ?></b></p>
    <div class="table-responsive">
        <div id="dataTable_wrapper" class="dataTables_wrapper dt-bootstrap4">
            <div class="row">
                <div class="col-sm-12">
                    <table class="table table-bordered dataTable hover compact" id="rekapPengukuran" cellspacing="0" role="grid" aria-describedby="dataTable_info">
                        <thead class="text-center">
                            <tr role="row">
                                <th class="sorting" tabindex="0" aria-controls="dataTable" rowspan="1" colspan="1" style="width: 20px;">No</th>
                                <th class="sorting" tabindex="0" aria-controls="dataTable" rowspan="1" colspan="1">Nama Anak</th>
                                <th class="sorting" tabindex="0" aria-controls="dataTable" rowspan="1" colspan="1">L/P</th>
                                <th class="sorting" tabindex="0" aria-controls="dataTable" rowspan="1" colspan="1">TTL</th>
                                <th class="sorting" tabindex="0" aria-controls="dataTable" rowspan="1" colspan="1">Nama Orang Tua</th>
                                <th class="sorting" tabindex="0" aria-controls="dataTable" rowspan="1" colspan="1" style="width: 20px;">Umur (bln)</th>
                                <th class="sorting" tabindex="0" aria-controls="dataTable" rowspan="1" colspan="1" style="width: 50px;">BB</th>
                                <th class="sorting" tabindex="0" aria-controls="dataTable" rowspan="1" colspan="1" style="width: 50px;">TB</th>
                                <th class="sorting" tabindex="0" aria-controls="dataTable" rowspan="1" colspan="1" style="width: 50px;">LK</th>
                                <th class="sorting" tabindex="0" aria-controls="dataTable" rowspan="1" colspan="1">N/T</th>
                                <th class="sorting" tabindex="0" aria-controls="dataTable" rowspan="1" colspan="1" style="width: 20px;">Asi Eks</th>
                                <th class="sorting" tabindex="0" aria-controls="dataTable" rowspan="1" colspan="1" style="width: 20px;">Vit A</th>
                                <th class="sorting" tabindex="0" aria-controls="dataTable" rowspan="1" colspan="1" style="width: 20px;">Status</th>
                            </tr>
                        </thead>
                        <tfoot class="text-center">
                            <tr>
                                <th rowspan="1" colspan="1">No</th>
                                <th rowspan="1" colspan="1">Nama Anak</th>
                                <th rowspan="1" colspan="1">L/P</th>
                                <th rowspan="1" colspan="1">TTL</th>
                                <th rowspan="1" colspan="1">Nama Orang Tua</th>
                                <th rowspan="1" colspan="1">Umur</th>
                                <th rowspan="1" colspan="1">BB</th>
                                <th rowspan="1" colspan="1">TB</th>
                                <th rowspan="1" colspan="1">LK</th>
                                <th rowspan="1" colspan="1">N/T</th>
                                <th rowspan="1" colspan="1">ASI</th>
                                <th rowspan="1" colspan="1">Vit A</th>
                                <th rowspan="1" colspan="1">Status</th>
                            </tr>
                        </tfoot>
                        <tbody>
                            <?php $no = 1;
                            foreach ($rekap as $p) { ?>
                                <tr role="row">
                                    <td><?= $no;
                                        $no++ ?></td>
                                    <td><?= $p->namabalita; ?></td>
                                    <td><?= $p->kelamin; ?></td>
                                    <td><?= date('j-M-Y', strtotime($p->tgllahir)); ?></td>
                                    <td><?= $p->ibu . " / " . $p->ayah; ?></td>
                                    <td class="text-center"><?= round($p->umur); ?></td>
                                    <td><?= $p->berat; ?></td>
                                    <td><?= $p->tinggi; ?></td>
                                    <td><?= $p->kepala; ?></td>
                                    <td class="text-center"><?= $p->keterangan; ?></td>
                                    <td class="text-center"><?= ($p->asi == 1 ? "Ya" : "Tidak"); ?></td>
                                    <td class="text-center"><?= ($p->vitamina == 1 ? "Ya" : "Tidak"); ?></td>
                                    <td class="text-center"><?= $p->statusbantuan; ?></td>
                                </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>
            </div>

        </div>
    </div>
</div>