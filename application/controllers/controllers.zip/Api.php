<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Api
extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('penduduk_model');
        $this->load->model('pengukuran_model');
    }
    function cari()
    {
        if (isset($_GET['term'])) {
            $result = $this->penduduk_model->getAyah($_GET['term']);
            if (count($result) > 0) {
                foreach ($result as $row)
                    $arr_result[] = $row->blog_title;
                echo json_encode($arr_result);
            }
        }
    }

    function getIdUkuran()
    {
        if (isset($_GET['nik']) && isset($_GET['idacara'])) {
            $result = $this->pengukuran_model->getIdUkuran($_GET['nik'], $_GET['idacara']);
            if (count($result) > 0) {
                echo json_encode($result);
            }
        }
    }
    function getDataPeserta()
    {
        if (isset($_GET['nik'])) {
            $result = $this->penduduk_model->getDataPeserta($_GET['nik']);
            if (count($result) > 0) {
                echo json_encode($result);
            } else echo "Data tidak ditemukan";
        }
    }

    function getUkuranLengkap()
    {
        if (isset($_GET['idpengukuran'])) {
            $result = $this->pengukuran_model->getUkuranLengkap($_GET['idpengukuran']);
            if (count($result) > 0) {
                echo json_encode($result);
            } else echo "Data tidak ditemukan";
        }
    }

    function getRekap()
    {
        if (isset($_GET['idacara'])) {
            $result = $this->pengukuran_model->getRekap($_GET['idacara']);
            if (count($result) > 0) {
                echo json_encode($result);
            } else echo "Data tidak ditemukan";
        }
    }
}
