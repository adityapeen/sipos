<!-- Begin Page Content -->
<div class="container-fluid" style="height : 300px; margin-top :150px">

    <!-- 404 Error Text -->
    <div class="text-center">
        <div class="error mx-auto" data-text="404">404</div>
        <p class="lead text-gray-800 mb-5">Halaman tidak Ditemukan</p>
        <button class="btn btn-warning" onclick="goBack()">Kembali</button>
    </div>

</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->