<?php
class excel
{
    function __construct()
    {
        include_once APPPATH . '/third_party/PhpSpreadsheet/Spreadsheet.php';
    }
}
